﻿using UnityEngine;
using System.Collections;

public class Script_Caparazon : MonoBehaviour
{

    public float VelocidadRotacionPadre;
    public float VelocidadRotacion;

    public GameObject objetivo;

    float Velocidad = 30f;
    int golpes = 0;

    // Use this for initialization
    void Start()
    {
        


    }

    // Update is called once per frame
    void Update()
    {
        

        if (transform.parent != null)
        {
            transform.parent.Rotate(new Vector3(0, 180, 0) * VelocidadRotacionPadre * Time.deltaTime);
            //transform.RotateAround(transform.parent.localPosition, Vector3.up, VelocidadRotacionPadre * Time.deltaTime);



            transform.Rotate(new Vector3(0, 180, 0) * VelocidadRotacion * Time.deltaTime);

            //Vector3 Mirar = transform.parent.position - transform.position;
            //Quaternion rotacion = Quaternion.LookRotation(Mirar);
            //transform.rotation = Quaternion.Slerp(transform.rotation, rotacion, VelocidadRotacion * Time.deltaTime);

            Physics.IgnoreLayerCollision(8, 9);

        }

        
        else if( transform.parent == null)
        {
            if (objetivo != null)
            {
                

                if (this.gameObject.tag == "Red_Shell" || this.gameObject.tag == "Blue_Shell")
                {
                    Vector3 IrObjetivo = objetivo.transform.position - transform.position;
                    Quaternion rotacion = Quaternion.LookRotation(IrObjetivo);
                    transform.rotation = Quaternion.Slerp(transform.rotation, rotacion, 5 * Time.deltaTime);


                }



                //if (this.gameObject.tag == "Green_Shell")
                //{


                //    //Vector3 IrObjetivo = objetivo.transform.position;
                //    //Quaternion rotacion = Quaternion.LookRotation(IrObjetivo);
                //    //transform.position = Vector3.Lerp(transform.position, IrObjetivo, 5 * Time.deltaTime);

                //    //Quaternion.Slerp(transform.rotation, rotacion, 5 * Time.deltaTime);
                //}

            }

            

           transform.Translate(Vector3.forward * Velocidad * Time.deltaTime, Space.Self);
        }



    }


    void OnCollisionEnter(Collision col)
    {
        if (col.gameObject)
        {
            if (objetivo == null)
            {
           
                float VelocidadOriginal = Velocidad;

                
                golpes++;

                if (golpes < 2)
                {
                   
                    Velocidad *= -1;
                }
                if (golpes > 2)
                {
                    Destroy(this.gameObject);
                    Velocidad = VelocidadOriginal;
                    golpes = 0;
                }

            }

            if (objetivo != null || col.gameObject.tag == "CPU")
            {
                

                    Destroy(this.gameObject);
                
            }



        }


        //if (this.gameObject.tag == "Red_Shell" || this.gameObject.tag == "Blue_Shell")
        //{
        //    //Vector3 IrObjetivo = objetivo.transform.position - transform.position;
        //    //Quaternion rotacion = Quaternion.LookRotation(IrObjetivo);
        //    //transform.rotation = Quaternion.Slerp(transform.rotation, rotacion, 5 * Time.deltaTime);
        //     if (col.gameObject)
        //    {
        //        Destroy(this.gameObject);
        //    }


        //}





    }



}

