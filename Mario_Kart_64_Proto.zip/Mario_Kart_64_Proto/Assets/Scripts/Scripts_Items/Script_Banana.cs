﻿using UnityEngine;
using System.Collections;

public class Script_Banana : MonoBehaviour {

    const string Suelo = "Suelo";
    Rigidbody Mirigi;
    CapsuleCollider colisionador;
    // Use this for initialization
    void Start ()
    {
        Mirigi = GetComponent<Rigidbody>();
        colisionador = GetComponent<CapsuleCollider>();
	
	}

    void Update()
    {


        Physics.IgnoreLayerCollision(10, 8);
    }
	
	// Update is called once per frame
	void OnCollisionEnter (Collision col)
    {
        if(col.gameObject.tag == Suelo)
        {
            transform.localScale = new Vector3(1, 1, 1);
            Destroy(Mirigi);
            colisionador.isTrigger = true;

        }
	
	}
}
