﻿using UnityEngine;
using System.Collections;
using UnityEngine.UI;

public class Items_UI : MonoBehaviour {

    public Sprite[] spritesObjetos;
    public Image[] Contenedor_Objetos;
    Item_Personaje Itemdeturno;

	// Use this for initialization
	void Start ()
    {
        Itemdeturno = GetComponent<Item_Personaje>();
	
	}

    // Update is called once per frame
    void Update()
    {
        if (Itemdeturno.TipoItem == Item_Personaje.ListaItems.Ninguno)
        {
            foreach (Image a in Contenedor_Objetos)
            {
                a.enabled = false;
            }
        }

        if (Itemdeturno.TipoItem == Item_Personaje.ListaItems.Banana)
        {
            foreach (Image a in Contenedor_Objetos)
            {
                a.enabled = true;
            }

            Contenedor_Objetos[1].sprite = spritesObjetos[0];
        }

        if (Itemdeturno.TipoItem == Item_Personaje.ListaItems.Un_Hongo)
        {
            foreach (Image a in Contenedor_Objetos)
            {
                a.enabled = true;
            }

            Contenedor_Objetos[1].sprite = spritesObjetos[1];
        }

        if (Itemdeturno.TipoItem == Item_Personaje.ListaItems.Falsa_Caja_Item)
        {
            foreach (Image a in Contenedor_Objetos)
            {
                a.enabled = true;
            }

            Contenedor_Objetos[1].sprite = spritesObjetos[2];
        }

        if (Itemdeturno.TipoItem == Item_Personaje.ListaItems.Caparazon_Verde)
        {
            foreach (Image a in Contenedor_Objetos)
            {
                a.enabled = true;
            }

            Contenedor_Objetos[1].sprite = spritesObjetos[3];
        }

        if (Itemdeturno.TipoItem == Item_Personaje.ListaItems.Caparazon_Rojo)
        {
            foreach (Image a in Contenedor_Objetos)
            {
                a.enabled = true;
            }

            Contenedor_Objetos[1].sprite = spritesObjetos[4];
        }

        if (Itemdeturno.TipoItem == Item_Personaje.ListaItems.Tres_Caparazones_Rojos)
        {
            foreach (Image a in Contenedor_Objetos)
            {
                a.enabled = true;
            }

            Contenedor_Objetos[1].sprite = spritesObjetos[5];
        }

        if (Itemdeturno.TipoItem == Item_Personaje.ListaItems.Tres_Caparazones_Verdes)
        {
            foreach (Image a in Contenedor_Objetos)
            {
                a.enabled = true;
            }

            Contenedor_Objetos[1].sprite = spritesObjetos[6];
        }

        if (Itemdeturno.TipoItem == Item_Personaje.ListaItems.Super_Hongo)
        {
            foreach (Image a in Contenedor_Objetos)
            {
                a.enabled = true;
            }

            Contenedor_Objetos[1].sprite = spritesObjetos[7];
        }

        if (Itemdeturno.TipoItem == Item_Personaje.ListaItems.Tres_Hongos)
        {
            foreach (Image a in Contenedor_Objetos)
            {
                a.enabled = true;
            }

            if (Itemdeturno.ValorHongos == 0)
            {
                Contenedor_Objetos[1].sprite = spritesObjetos[8];
            }
            if (Itemdeturno.ValorHongos == 1)
            {
                Contenedor_Objetos[1].sprite = spritesObjetos[9];
            }

            if (Itemdeturno.ValorHongos == 2)
            {
                Contenedor_Objetos[1].sprite = spritesObjetos[1];
            }

        }

        if (Itemdeturno.TipoItem == Item_Personaje.ListaItems.Estrella)
        {
            foreach (Image a in Contenedor_Objetos)
            {
                a.enabled = true;
            }

            Contenedor_Objetos[1].sprite = spritesObjetos[10];
        }

        if (Itemdeturno.TipoItem == Item_Personaje.ListaItems.Racimo_Bananas)
        {
            foreach (Image a in Contenedor_Objetos)
            {
                a.enabled = true;
            }

            Contenedor_Objetos[1].sprite = spritesObjetos[11];
        }

        if (Itemdeturno.TipoItem == Item_Personaje.ListaItems.Caparazon_Azul)
        {
            foreach (Image a in Contenedor_Objetos)
            {
                a.enabled = true;
            }

            Contenedor_Objetos[1].sprite = spritesObjetos[12];
        }

        if (Itemdeturno.TipoItem == Item_Personaje.ListaItems.Rayo)
        {
            foreach (Image a in Contenedor_Objetos)
            {
                a.enabled = true;
            }

            Contenedor_Objetos[1].sprite = spritesObjetos[13];
        }

        if (Itemdeturno.TipoItem == Item_Personaje.ListaItems.Fantasma)
        {
            foreach (Image a in Contenedor_Objetos)
            {
                a.enabled = true;
            }

            Contenedor_Objetos[1].sprite = spritesObjetos[14];
        }

    }
}
