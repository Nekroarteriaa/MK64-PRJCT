﻿using UnityEngine;
using System.Collections;
using UnityEngine.UI;

public class ContadorLaps : MonoBehaviour {

    // GameObject[] arregloTrigers;
    public int vueltas;
    public bool check1;
    public bool check2;
    public bool check3;

    

    const string meta = "Meta_Trigger";
    const string primero = "Primer_Trigger";
    const string segundo = "Segundo_Trigger";
    const string tercero = "Tercer_Trigger";

    public int PosicionEnLaCarrera;

    public float DistanciaPersonal;

    public Sprite ImagenJugador;

    // Use this for initialization
    void Update ()
    {

        //arregloTrigers = GameObject.FindGameObjectsWithTag("Salida");
        if(vueltas == 4 && PosicionEnLaCarrera == 1)
        {
            print(transform.name + " gano el juego");
            Time.timeScale = 0;
        }
        





    }

    // Update is called once per frame
    void OnTriggerEnter(Collider col)
    {
        if (col.gameObject.name == primero)
        {
            check1 = true;
        }

        if (col.gameObject.name == segundo)
        {
            check2 = true;
        }

        if (col.gameObject.name == tercero)
        {
            check3 = true;
        }

        if (col.gameObject.name == meta && check1 && check2 && check3)
        {
            vueltas++;

            if(this.transform.tag == "CPU")
            {
                this.gameObject.GetComponent<Posicion_de_seguido>().pos = 0;
            }
            
        }

    }

    void OnTriggerExit(Collider col)
    {
       

        if (col.gameObject.name == meta && check1 && check2 && check3)
        {
            
            check1 = false;
            check2 = false;
            check3 = false;
        }

    }
}
