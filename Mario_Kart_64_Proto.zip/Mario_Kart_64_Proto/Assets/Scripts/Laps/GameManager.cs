﻿using UnityEngine;
using System.Collections;

public class GameManager : MonoBehaviour
{
    private static GameManager _instancia;

    public static GameManager Instancia
    {
        get
        {
            if(_instancia == null)
            {
                GameObject go = new GameObject("GameManager");
                go.AddComponent<GameManager>();
            }

            return _instancia;
        }
    }

    public GameObject[] arregloPosicion = new GameObject[3];

    void Awake()
    {
        _instancia = this;
    }

    //public void MiPosicion(GameObject Yo)
    //{
    //    for(int i = 0; i< arregloPosicion.Length; i++)
    //    {
    //        if(arregloPosicion[i].name == Yo.name)
    //        {

    //        }
    //    }
    //}
    
}
