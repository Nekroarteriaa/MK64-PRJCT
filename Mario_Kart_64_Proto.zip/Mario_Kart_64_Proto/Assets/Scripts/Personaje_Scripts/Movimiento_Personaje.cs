﻿using UnityEngine;
using System.Collections;

public class Movimiento_Personaje : MonoBehaviour {

    public float Rotacion;
    public float velocidad;
    float direccion = 1;
    Rigidbody rigi;
    float velocidadOriginal;

    bool PuedeAcelerar;
    bool PuedeReversa;

    public Item_Personaje Item = null;
    public float Impacto;

    CapsuleCollider colisionador;
    bool ToqueBanana;
    GameObject objetoTocado;

    public bool GolpeCaparazon;
    public bool Estasuelo;

    public float VelocidadRotacion;

    // Use this for initialization

    void Awake()
    {
        velocidadOriginal = velocidad;
    }

	void Start ()
    {
        rigi = GetComponent<Rigidbody>();
        Item = GetComponent<Item_Personaje>();
        colisionador = GetComponent<CapsuleCollider>();
        velocidad = 0;
	
	}

    // Update is called once per frame
    void FixedUpdate()
    {

        float GirodeDireccion = Input.GetAxis("Horizontal");

        if (GirodeDireccion != 0 && PuedeAcelerar || GirodeDireccion != 0 && PuedeReversa)
        {




            Vector3 MovimientoLateral = new Vector3(GirodeDireccion, 0, 0);
            MovimientoLateral = transform.TransformDirection(MovimientoLateral);
            Quaternion ObjetivoRotacion = Quaternion.LookRotation(MovimientoLateral, Vector3.up);
            Quaternion nuevaRotacion = Quaternion.Lerp(rigi.rotation, ObjetivoRotacion, Rotacion * Time.deltaTime);
            rigi.MoveRotation(nuevaRotacion);
        }


        if (Input.GetKeyUp(KeyCode.N))//||  Input.GetKeyUp(KeyCode.M))
        {
            PuedeAcelerar = false;
        }

        if (Input.GetKeyUp(KeyCode.M))//||  Input.GetKeyUp(KeyCode.M))
        {
            PuedeReversa = false;
        }


        if (Input.GetKey(KeyCode.N))
        {
            PuedeAcelerar = true;
            PuedeReversa = false;


        }

        if (Input.GetKey(KeyCode.M))
        {
            PuedeReversa = true;
            PuedeAcelerar = false;
        }


        if(PuedeAcelerar)
        {
           

            if (velocidad < velocidadOriginal)
            {
                velocidad += Time.deltaTime * 2.8f;
            }

            Vector3 movimiento = Vector3.forward * direccion * velocidad * Time.deltaTime;
            movimiento = transform.TransformDirection(movimiento);
            rigi.MovePosition(rigi.position + movimiento);
        }

        if(PuedeReversa)
        {
           

            if (velocidad > -velocidadOriginal)
            {
                velocidad += Time.deltaTime * -2.8f;
            }

            Vector3 movimiento = Vector3.forward * direccion * velocidad * Time.deltaTime;
            movimiento = transform.TransformDirection(movimiento);
            rigi.MovePosition(rigi.position + movimiento);
        }

        if(!PuedeAcelerar && velocidad > 0)
        {
            velocidad += Time.deltaTime * -2.8f;

            if (velocidad <= 0)
            {
                velocidad = 0;
            }

            Vector3 movimiento = Vector3.forward * direccion * velocidad * Time.deltaTime;
            movimiento = transform.TransformDirection(movimiento);
            rigi.MovePosition(rigi.position + movimiento);
        }

        if (!PuedeReversa && velocidad < 0)
        {
            velocidad += Time.deltaTime * 2.8f;

            if (velocidad >= 0)
            {
                velocidad = 0;
            }

            Vector3 movimiento = Vector3.forward * direccion * velocidad * Time.deltaTime;
            movimiento = transform.TransformDirection(movimiento);
            rigi.MovePosition(rigi.position + movimiento);
        }



        if (ToqueBanana)
        {
            transform.Rotate(new Vector3(0, 360, 0) * Time.deltaTime * VelocidadRotacion);

            velocidad -= Time.deltaTime * 150f;

            if (velocidad <= 0)
            {
                ToqueBanana = false;
            }
        }


    }

    void OnCollisionEnter(Collision col)
    {

        if(col.gameObject.tag == "Pared")
        {
            print(col.contacts[0].normal);
            if (col.contacts[0].normal.x > 0)
            {
                Vector3 movimiento = Vector3.back * Impacto * 3 * Time.deltaTime;
                movimiento = transform.TransformDirection(movimiento);
                rigi.MovePosition(rigi.position + movimiento);
            }

            if (col.contacts[0].normal.x < 0)
            {
                Vector3 movimiento = Vector3.forward * Impacto * 3 * Time.deltaTime;
                movimiento = transform.TransformDirection(movimiento);
                rigi.MovePosition(rigi.position + movimiento);
            }
        }


        if (col.gameObject.tag == "CPU")
        {

            if (col.gameObject.GetComponent<Agarre_Item>().EstoyChico)
            {
                //Vector3 golpeArriba = Vector3.up * Impacto * 10 * Time.deltaTime;
                //golpeArriba = col.transform.TransformDirection(golpeArriba);
                //Rigidbody rigiEnemigo = col.transform.GetComponent<Rigidbody>();
                //rigiEnemigo.MovePosition(rigiEnemigo.position + golpeArriba);
                //col.transform.GetComponent<Comp_Dos>().velocidad = 0;
                //col.transform.GetComponent<Comp_Dos>().GolpeCaparazon = true;
                col.gameObject.GetComponent<Agarre_Item>().EstoyChico = false;
            }


            if (Item.TengoFantasma)
            {
                objetoTocado = col.gameObject;
                //colisionador.enabled = false;
                //colisionador.isTrigger = true;
                //rigi.useGravity = false;
                Physics.IgnoreCollision(colisionador, objetoTocado.gameObject.GetComponent<CapsuleCollider>());




            }



            if (col.transform.GetComponent<Comp_Dos>().Item.tengoRacimo)
            {
                int hijos = transform.FindChild("Guarda_Platano").childCount;

                if (hijos != 0)
                {
                    for (int i = 0; i < hijos; i++)
                    {
                        float weaRandom = Random.Range(-50f, 50f);
                        col.transform.GetComponent<Comp_Dos>().transform.FindChild("Guarda_Platano").GetChild(i).GetChild(0).transform.Translate(new Vector3(weaRandom, 0, weaRandom) * Time.deltaTime);
                        col.transform.GetComponent<Comp_Dos>().transform.FindChild("Guarda_Platano").GetChild(i).GetChild(0).transform.parent = null;
                        col.transform.GetComponent<Comp_Dos>().Item.tengoRacimo = false;
                        ToqueBanana = true;


                    }
                }



            }




            if (Item.tengoCaparazon)
            {

                if (col.transform.GetComponent<Comp_Dos>().Item.tengoCaparazon)
                {

                    Destroy(col.transform.FindChild("Guarda_Choncha").GetChild(0).gameObject);
                    Destroy(transform.FindChild("Guarda_Choncha").GetChild(0).gameObject);
                }

                if (!col.transform.GetComponent<Comp_Dos>().Item.tengoCaparazon && !col.transform.GetComponent<Comp_Dos>().Item.TengoFantasma && !col.transform.GetComponent<Comp_Dos>().Item.TengoEstrella)
                {
                    Vector3 golpeArriba = Vector3.up * Impacto * 10 * Time.deltaTime;
                    golpeArriba = col.transform.TransformDirection(golpeArriba);
                    Rigidbody rigiEnemigo = col.transform.GetComponent<Rigidbody>();
                    rigiEnemigo.MovePosition(rigiEnemigo.position + golpeArriba);
                    col.transform.GetComponent<Comp_Dos>().velocidad = 0;
                    col.transform.GetComponent<Comp_Dos>().GolpeCaparazon = true;
                    Destroy(transform.FindChild("Guarda_Choncha").GetChild(0).gameObject);
                }

                if (col.transform.GetComponent<Comp_Dos>().Item.tengoRacimo)
                {


                    int hijos = col.transform.FindChild("Guarda_Platano").childCount;

                    //transform.FindChild("Guarda_Platano").parent = null;

                    for (int i = 0; i <= hijos - 1; i++)
                    {
                        float weaRandom = Random.Range(-50f, 50f);

                        col.transform.FindChild("Guarda_Platano").GetChild(i).GetChild(0).transform.Translate(new Vector3(weaRandom, 0, weaRandom) * Time.deltaTime);
                        col.transform.FindChild("Guarda_Platano").GetChild(i).GetChild(0).transform.parent = null;
                        col.transform.GetComponent<Comp_Dos>().Item.tengoRacimo = false;




                    }


                }

                if (col.gameObject.GetComponent<Agarre_Item>().EstoyChico)
                {
                    col.gameObject.GetComponent<Agarre_Item>().EstoyChico = false;
                }

            }


            if (Item.TengoEstrella)
            {

                if (!col.transform.GetComponent<Comp_Dos>().Item.TengoEstrella)
                {


                    Vector3 golpeArriba = Vector3.up * Impacto * 10 * Time.deltaTime;
                    golpeArriba = col.transform.TransformDirection(golpeArriba);
                    Rigidbody rigiEnemigo = col.transform.GetComponent<Rigidbody>();
                    rigiEnemigo.MovePosition(rigiEnemigo.position + golpeArriba);
                    col.transform.GetComponent<Comp_Dos>().velocidad = 0;
                    col.transform.GetComponent<Comp_Dos>().GolpeCaparazon = true;

                }

                if (col.transform.GetComponent<Comp_Dos>().Item.TengoEstrella)
                {


                    if (col.contacts[0].normal.x < 0)
                    {
                        //col.transform.Translate(Vector3.left * Impacto * Time.deltaTime);

                        Vector3 golpeEnemigo = Vector3.left * Impacto * Time.deltaTime;
                        golpeEnemigo = col.transform.TransformDirection(golpeEnemigo);
                        Rigidbody rigiEnemigo = col.transform.GetComponent<Rigidbody>();
                        rigiEnemigo.MovePosition(rigiEnemigo.position + golpeEnemigo);

                        //transform.Translate(Vector3.right * Impacto * Time.deltaTime);



                        //Vector3 golpe = Vector3.right * Impacto * Time.deltaTime;
                        //golpe = transform.TransformDirection(golpe);
                        //rigi.MovePosition(rigi.position + golpe);
                    }

                    if (col.contacts[0].normal.x > 0)
                    {
                        Vector3 golpeEnemigo = Vector3.right * Impacto * Time.deltaTime;
                        golpeEnemigo = col.transform.TransformDirection(golpeEnemigo);
                        Rigidbody rigiEnemigo = col.transform.GetComponent<Rigidbody>();
                        rigiEnemigo.MovePosition(rigiEnemigo.position + golpeEnemigo);

                        //transform.Translate(Vector3.right * Impacto * Time.deltaTime);



                        //Vector3 golpe = Vector3.left * Impacto * Time.deltaTime;
                        //golpe = transform.TransformDirection(golpe);
                        //rigi.MovePosition(rigi.position + golpe);
                    }
                }

                if (col.gameObject.GetComponent<Agarre_Item>().EstoyChico)
                {
                    col.gameObject.GetComponent<Agarre_Item>().EstoyChico = false;
                }

            }

            if (col.transform.GetComponent<Comp_Dos>().Item.TengoEstrella && !Item.TengoEstrella)
            {
                Vector3 golpeArriba = Vector3.up * Impacto * 10 * Time.deltaTime;
                golpeArriba = transform.TransformDirection(golpeArriba);

                rigi.MovePosition(rigi.position + golpeArriba);
                velocidad = 0;
                GolpeCaparazon = true;

                if(transform.FindChild("Guarda_Choncha") != null)
                {
                    Destroy(transform.FindChild("Guarda_Choncha").gameObject);
                }

                if(Item.TipoItem != 0)
                {
                    Item.TipoItem = Item_Personaje.ListaItems.Ninguno;
                }

               
            }

                //    if (col.contacts[0].normal.x < 0)
                //    {
                //        //col.transform.Translate(Vector3.left * Impacto * Time.deltaTime);

                //        Vector3 golpeEnemigo = Vector3.left * Impacto * Time.deltaTime;
                //        golpeEnemigo = col.transform.TransformDirection(golpeEnemigo);
                //        Rigidbody rigiEnemigo = col.transform.GetComponent<Rigidbody>();
                //        rigiEnemigo.MovePosition(rigiEnemigo.position + golpeEnemigo);

                //        //transform.Translate(Vector3.right * Impacto * Time.deltaTime);



                //        //Vector3 golpe = Vector3.right * Impacto * Time.deltaTime;
                //        //golpe = transform.TransformDirection(golpe);
                //        //rigi.MovePosition(rigi.position + golpe);
                //    }

                //    if (col.contacts[0].normal.x > 0)
                //    {
                //        Vector3 golpeEnemigo = Vector3.right * Impacto * Time.deltaTime;
                //        golpeEnemigo = col.transform.TransformDirection(golpeEnemigo);
                //        Rigidbody rigiEnemigo = col.transform.GetComponent<Rigidbody>();
                //        rigiEnemigo.MovePosition(rigiEnemigo.position + golpeEnemigo);

                //        //transform.Translate(Vector3.right * Impacto * Time.deltaTime);



                //        //Vector3 golpe = Vector3.left * Impacto * Time.deltaTime;
                //        //golpe = transform.TransformDirection(golpe);
                //        //rigi.MovePosition(rigi.position + golpe);
                //    }

            }

        if (col.gameObject.tag == "Red_Shell")
        {
            if (!Item.TengoEstrella)
            {
                if (!Item.tengoCaparazon && !Item.tengoRacimo || Item.tengoRacimo && col.contacts[0].normal.y > -.3)
                {
                    Vector3 golpeArriba = Vector3.up * Impacto * 10 * Time.deltaTime;
                    golpeArriba = transform.TransformDirection(golpeArriba);

                    rigi.MovePosition(rigi.position + golpeArriba);
                    velocidad = 0;
                    GolpeCaparazon = true;

                }

                if (Item.tengoCaparazon)
                {
                    if (transform.FindChild("Guarda_Choncha").childCount > 0)
                    {
                        Destroy(transform.FindChild("Guarda_Choncha").GetChild(0).gameObject);
                    }

                    else
                    {
                        Destroy(transform.FindChild("Guarda_Choncha").gameObject);
                        Item.tengoCaparazon = false;
                    }

                }

                if (Item.tengoRacimo)
                {
                    int hijos = transform.FindChild("Guarda_Platano").childCount;




                    if (col.contacts[0].normal.y > -.3)
                    {
                        //transform.FindChild("Guarda_Platano").parent = null;



                        if (hijos != 0)
                        {
                            for (int i = 0; i < hijos; i++)
                            {
                                float weaRandom = Random.Range(-50f, 50f);
                                transform.FindChild("Guarda_Platano").GetChild(i).GetChild(0).transform.Translate(new Vector3(weaRandom, 0, weaRandom) * Time.deltaTime);
                                transform.FindChild("Guarda_Platano").GetChild(i).GetChild(0).transform.parent = null;
                                Item.tengoRacimo = false;
                                Destroy(col.gameObject);


                            }
                        }

                        if (hijos <= 0)
                        {
                            Destroy(col.gameObject);
                            //Destroy(transform.FindChild("Guarda_Platano"));
                            Item.tengoRacimo = false;
                        }


                    }

                    if (col.contacts[0].normal.y <= -.3)
                    {
                        int hijoOcurrente = transform.GetComponent<Agarre_Item>().hijos;
                        Destroy(transform.FindChild("Guarda_Platano").GetChild(hijoOcurrente - 1).GetChild(0).gameObject);
                        transform.GetComponent<Agarre_Item>().hijos--;
                    }
                }

                if (Item.EstoyChico)
                {
                    Item.EstoyChico = false;
                }
            }

            if (Item.TengoEstrella)
            {
                Destroy(col.gameObject);
            }

            if (Item.TengoFantasma)
            {
                objetoTocado = col.gameObject;
                //colisionador.enabled = false;
                //colisionador.isTrigger = true;
                //rigi.useGravity = false;
                Physics.IgnoreCollision(colisionador, objetoTocado.gameObject.GetComponent<SphereCollider>());
            }

        }

        if (col.gameObject.tag == "Green_Shell")
        {
            

            if (!Item.TengoEstrella)
            {
                if (!Item.tengoCaparazon && !Item.tengoRacimo || Item.tengoRacimo && col.contacts[0].normal.y > -.3)
                {
                    Vector3 golpeArriba = Vector3.up * Impacto * 10 * Time.deltaTime;
                    golpeArriba = transform.TransformDirection(golpeArriba);

                    rigi.MovePosition(rigi.position + golpeArriba);
                    velocidad = 0;
                    GolpeCaparazon = true;

                }

                if (Item.tengoCaparazon)
                {

                    if (transform.FindChild("Guarda_Choncha").childCount != 0)
                    {
                        Destroy(transform.FindChild("Guarda_Choncha").GetChild(0).gameObject);
                    }

                    else
                    {
                        Destroy(transform.FindChild("Guarda_Choncha").gameObject);
                        Item.tengoCaparazon = false;
                    }
                }

                if (Item.tengoRacimo)
                {
                    int hijos = transform.FindChild("Guarda_Platano").childCount;




                    if (col.contacts[0].normal.y > -.3)
                    {
                        //transform.FindChild("Guarda_Platano").parent = null;

                        if (hijos != 0)
                        {
                            for (int i = 0; i < hijos; i++)
                            {
                                float weaRandom = Random.Range(-50f, 50f);
                                transform.FindChild("Guarda_Platano").GetChild(i).GetChild(0).transform.Translate(new Vector3(weaRandom, 0, weaRandom) * Time.deltaTime);
                                transform.FindChild("Guarda_Platano").GetChild(i).GetChild(0).transform.parent = null;
                                Item.tengoRacimo = false;
                                Destroy(col.gameObject);


                            }
                        }

                        if (hijos <= 0)
                        {
                            Destroy(col.gameObject);
                            // Destroy(transform.FindChild("Guarda_Platano"));
                            Item.tengoRacimo = false;
                        }


                    }

                    if (col.contacts[0].normal.y <= -.3)
                    {
                        int hijoOcurrente = transform.GetComponent<Agarre_Item>().hijos;
                        Destroy(transform.FindChild("Guarda_Platano").GetChild(hijoOcurrente - 1).GetChild(0).gameObject);
                        transform.GetComponent<Agarre_Item>().hijos--;
                    }
                }

                if (Item.EstoyChico)
                {
                    Item.EstoyChico = false;
                }
            }

            if (Item.TengoEstrella)
            {
                Destroy(col.gameObject);
            }
        }


        if (col.gameObject.tag == "Blue_Shell")
        {

            //    Vector3 golpeArriba = Vector3.up * Impacto * 10 * Time.deltaTime;
            //    golpeArriba = col.transform.TransformDirection(golpeArriba);

            //    rigi.MovePosition(rigi.position + golpeArriba);
            //    velocidad = 0;
            //    GolpeCaparazon = true;



            //if (Item.tengoCaparazon)
            //{

            //    Destroy(transform.FindChild("Guarda_Choncha").gameObject);
            //}

            if(Item.TipoItem != 0)
            {
                Item.TipoItem = Item_Personaje.ListaItems.Ninguno;
            }

            if (!Item.TengoEstrella)
            {
                if (!Item.tengoCaparazon)
                {
                    Vector3 golpeArriba = Vector3.up * Impacto * 10 * Time.deltaTime;
                    golpeArriba = transform.TransformDirection(golpeArriba);

                    rigi.MovePosition(rigi.position + golpeArriba);
                    velocidad = 0;
                    GolpeCaparazon = true;

                }

                if (Item.tengoCaparazon)
                {
                    Vector3 golpeArriba = Vector3.up * Impacto * 10 * Time.deltaTime;
                    golpeArriba = transform.TransformDirection(golpeArriba);

                    rigi.MovePosition(rigi.position + golpeArriba);
                    velocidad = 0;
                    GolpeCaparazon = true;
                    Destroy(transform.FindChild("Guarda_Choncha").gameObject);
                }

                if (Item.tengoRacimo)
                {
                    int hijos = transform.FindChild("Guarda_Platano").childCount;

                    for (int i = 0; i <= hijos - 1; i++)
                    {
                        float weaRandom = Random.Range(-50f, 50f);
                        transform.FindChild("Guarda_Platano").GetChild(i).GetChild(0).transform.Translate(new Vector3(weaRandom, 0, weaRandom) * Time.deltaTime);
                        transform.FindChild("Guarda_Platano").GetChild(i).GetChild(0).transform.parent = null;
                        Item.tengoRacimo = false;


                    }

                }

                if (Item.EstoyChico)
                {
                    Item.EstoyChico = false;
                }

            }

            if (Item.TengoEstrella)
            {
                Destroy(col.gameObject);
            }
        }






    }

    void OnCollisionStay(Collision col)
    {

        if (col.gameObject.tag == "Suelo")
        {
            Estasuelo = true;
            GolpeCaparazon = false;
            //if(col.transform.GetComponent<Comp_Dos>().GolpeCaparazon)
            // {
            //     col.transform.GetComponent<Comp_Dos>().velocidad = velocidadOriginal;
            //     col.transform.GetComponent<Comp_Dos>().GolpeCaparazon = false;
            // }
        }


        if (col.gameObject.tag == "CPU")
        {







            if (col.contacts[0].normal.x < 0)
            {
                //col.transform.Translate(Vector3.left * Impacto * Time.deltaTime);

                Vector3 golpeEnemigo = Vector3.left * Impacto * Time.deltaTime;
                golpeEnemigo = col.transform.TransformDirection(golpeEnemigo);
                Rigidbody rigiEnemigo = col.transform.GetComponent<Rigidbody>();
                rigiEnemigo.MovePosition(rigiEnemigo.position + golpeEnemigo);


                Vector3 movimiento = Vector3.right * Impacto * Time.deltaTime;
                movimiento = transform.TransformDirection(movimiento);
                rigi.MovePosition(rigi.position + movimiento);



                //transform.Translate(Vector3.right * Impacto * Time.deltaTime);



                //Vector3 golpe = Vector3.right * Impacto * Time.deltaTime;
                //golpe = transform.TransformDirection(golpe);
                //rigi.MovePosition(rigi.position + golpe);
            }

            if (col.contacts[0].normal.x > 0)
            {
                Vector3 golpeEnemigo = Vector3.right * Impacto * Time.deltaTime;
                golpeEnemigo = col.transform.TransformDirection(golpeEnemigo);
                Rigidbody rigiEnemigo = col.transform.GetComponent<Rigidbody>();
                rigiEnemigo.MovePosition(rigiEnemigo.position + golpeEnemigo);


                Vector3 movimiento = Vector3.left * Impacto * Time.deltaTime;
                movimiento = transform.TransformDirection(movimiento);
                rigi.MovePosition(rigi.position + movimiento);

                //transform.Translate(Vector3.right * Impacto * Time.deltaTime);



                //Vector3 golpe = Vector3.left * Impacto * Time.deltaTime;
                //golpe = transform.TransformDirection(golpe);
                //rigi.MovePosition(rigi.position + golpe);
            }

        }



        //if (col.gameObject.tag == "Suelo")
        //{
        //    EstaSuelo = false;
        //}
    }

    void OnCollisionExit(Collision col)
    {

        if (col.gameObject.tag == "Suelo")
        {
            Estasuelo = false;
            //if(col.transform.GetComponent<Comp_Dos>().GolpeCaparazon)
            // {
            //     col.transform.GetComponent<Comp_Dos>().velocidad = velocidadOriginal;
            //     col.transform.GetComponent<Comp_Dos>().GolpeCaparazon = false;
            // }
        }



    }

    void OnTriggerEnter(Collider col)
    {




        if (col.gameObject.tag == "Banana")
        {
            if (!Item.TengoEstrella || !Item.tengoCaparazon)
            {
                ToqueBanana = true;

                Destroy(col.gameObject);

            }

            if (Item.TengoEstrella || Item.tengoCaparazon)
            {

                ToqueBanana = false;
                Destroy(col.gameObject);

            }

            if (Item.tengoRacimo)
            {
                int hijos = transform.FindChild("Guarda_Platano").childCount;

                if (hijos != 0)
                {
                    for (int i = 0; i < hijos; i++)
                    {
                        float weaRandom = Random.Range(-50f, 50f);

                        if (transform.FindChild("Guarda_Platano").GetChild(i).childCount != 0)
                        {
                            transform.FindChild("Guarda_Platano").GetChild(i).GetChild(0).transform.Translate(new Vector3(weaRandom, 0, weaRandom) * Time.deltaTime);
                            transform.FindChild("Guarda_Platano").GetChild(i).GetChild(0).transform.parent = null;
                            Item.tengoRacimo = false;
                            Destroy(col.gameObject);
                        }





                    }
                }

                if (hijos <= 0)
                {
                    Destroy(col.gameObject);
                }



            }


        }

        if (col.gameObject.tag == "Item_Falso")
        {
            if (!Item.TengoEstrella || !Item.tengoCaparazon)
            {
                Vector3 golpeArriba = Vector3.up * Impacto * 10 * Time.deltaTime;
                golpeArriba = transform.TransformDirection(golpeArriba);

                rigi.MovePosition(rigi.position + golpeArriba);
                velocidad = 0;
                GolpeCaparazon = true;

                Destroy(col.gameObject);
                Destroy(col.gameObject.transform.parent.gameObject);
                Destroy(col.gameObject.transform.parent.GetChild(1).gameObject);

            }

            if (Item.TengoEstrella || Item.tengoCaparazon)
            {
                GolpeCaparazon = false;
                Destroy(col.gameObject);
                Destroy(col.gameObject.transform.parent.gameObject);
                Destroy(col.gameObject.transform.parent.GetChild(1).gameObject);

            }

            if (Item.tengoRacimo)
            {
                int hijos = transform.FindChild("Guarda_Platano").childCount;
                if (hijos != 0)
                {
                    for (int i = 0; i < hijos; i++)
                    {
                        float weaRandom = Random.Range(-50f, 50f);
                        transform.FindChild("Guarda_Platano").GetChild(i).GetChild(0).transform.Translate(new Vector3(weaRandom, 0, weaRandom) * Time.deltaTime);
                        transform.FindChild("Guarda_Platano").GetChild(i).GetChild(0).transform.parent = null;
                        Item.tengoRacimo = false;
                        Destroy(col.gameObject);


                    }
                }

                if (hijos <= 0)
                {
                    Destroy(col.gameObject);
                }


            }
        }
    }

}
