﻿using UnityEngine;
using System.Collections;

public class Rotacion_Cubo : MonoBehaviour {

    float RotacionX;
    float RotacionY;
    float RotacionZ;

    // Use this for initialization
    void Start()
    {
        RotacionX = Random.Range(65, 180);
        RotacionY = Random.Range(65, 180);
        RotacionZ = Random.Range(65, 180);



    }
	
	// Update is called once per frame
	void Update ()
    {
        transform.Rotate(new Vector3(RotacionX, RotacionY, RotacionZ) * Time.deltaTime);

        
	
	}
}
