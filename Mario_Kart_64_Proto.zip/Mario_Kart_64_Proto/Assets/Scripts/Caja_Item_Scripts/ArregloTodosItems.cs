﻿using UnityEngine;
using System.Collections;
using UnityEngine.UI;

public class ArregloTodosItems : MonoBehaviour {

    public Image[] spritesItems;
    public GameObject[] arregloItems;

    /*

         /// primer puesto
        Banana,
        Un_Hongo,
        Falsa_Caja_Item,
        Caparazon_Verde,

        /// segundo puesto
        Caparazon_Rojo,
        Tres_Caparazones_Rojos,
        Tres_Caparazones_Verdes,

        /// Tercer puesto
        Super_Hongo,
        Tres_Hongos,
        Estrella,
        Racimo_Bananas, // son 6 bananas;

       
        Caparazon_Azul,
        Rayo,
        Fantasma

    */

    // Use this for initialization
    void Start () {
	
	}
	
	// Update is called once per frame
	void Update () {
	
	}
}
