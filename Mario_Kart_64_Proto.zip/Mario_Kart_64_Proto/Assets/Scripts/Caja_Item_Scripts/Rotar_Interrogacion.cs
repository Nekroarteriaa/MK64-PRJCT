﻿using UnityEngine;
using System.Collections;

public class Rotar_Interrogacion : MonoBehaviour {

    float Vel_Rotacion;

	// Use this for initialization
	void Start ()
    {
        Vel_Rotacion = Random.Range(80, 91);
        int Variacion = Random.Range(1, 3);
        if (Variacion >= 1)
        {
            Vel_Rotacion *= -1;
        }

       

    }
	
	// Update is called once per frame
	void Update ()
    {
        
        transform.Rotate(Vector3.up * Vel_Rotacion * Time.deltaTime);
	
	}
}
