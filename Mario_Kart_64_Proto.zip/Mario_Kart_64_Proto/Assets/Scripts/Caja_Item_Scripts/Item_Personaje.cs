﻿using UnityEngine;
using System.Collections;

public class Item_Personaje : MonoBehaviour {

	 ArregloTodosItems TodoslosItems;
    Movimiento_Personaje Atributos;
    float velocidadOriginal;

    bool Encencido;


    GameObject[] Particulas1 = new GameObject[2];
    GameObject[] Particulas2 = new GameObject[2];

    /// Hongos
    float tiempo;
    int contador;
    int limiteContador;
    public int ValorHongos;


    // Caparazones
    bool CaparazonRoja;
    bool CaparazonVerde;
    int NumeroCaparazon;
    public bool tengoCaparazon;
    bool CaparazonAzul;

    //Estrella
    public bool TengoEstrella;
    MeshRenderer[] MeshOriginal = null;
    Color[] ColorOriginal = null;

    /// Fantasma
    public bool TengoFantasma;
    float transparencia = 1;
    public Shader chader1;
    public Shader chaderOriginal;

    /// Racimo

    public bool tengoRacimo;
    public GameObject vacioPlatano;
    public int hijos;

    /// Rayo

    public bool EstoyChico;
    
    ////////////////////

    public enum ListaItems
    {
        /*  Recuerda que aunque vallas en ultimo lugar puedes sacar objetos del primer puesto aunque en menor medida
            pero el primer lugar no puede ni debe sacar items del ultimo puesto

            Otro ejemplo un jugador que va en tercero no puede sacar objetos del quinto lugar pero el quinto lugar si 
            puede sacar objetos del tercero
        */

        Ninguno,

        /// primer puesto
        Banana,
        Un_Hongo,
        Falsa_Caja_Item,
        Caparazon_Verde,

        /// segundo puesto
        Caparazon_Rojo,
        Tres_Caparazones_Rojos,
        Tres_Caparazones_Verdes,

        /// Tercer puesto
        Super_Hongo,
        Tres_Hongos,
        Estrella,
        Racimo_Bananas, // son 6 bananas;


        Caparazon_Azul,
        Rayo,
        Fantasma


    }

    public ListaItems TipoItem;

    void Awake()
    {
        TodoslosItems = GameObject.FindObjectOfType<ArregloTodosItems>();
        Atributos = GetComponent<Movimiento_Personaje>();
        velocidadOriginal = Atributos.velocidad;

        Particulas1[0] = transform.FindChild("1_encendido").gameObject;
        Particulas1[1] = transform.FindChild("2_encendido").gameObject;


        Particulas2[0] = transform.FindChild("1_apagado").gameObject;
        Particulas2[1] = transform.FindChild("2_apagado").gameObject;//GameObject.FindGameObjectsWithTag("Part_Encendido"); //transform.FindChild("1_encendido").GetComponent<ParticleSystem>();



        foreach (GameObject a in Particulas1)
        {
            a.SetActive(false);
        }


        MeshOriginal = GetComponentsInChildren<MeshRenderer>();
        ColorOriginal = new Color[MeshOriginal.Length];

        for (int i = 0; i < MeshOriginal.Length; i++)
        {
            ColorOriginal[i] = MeshOriginal[i].material.color;
            // renderizador[i].material.SetColor("_Color", colorRand);
        }

        vacioPlatano.SetActive(false);
        hijos = vacioPlatano.transform.childCount;
        //chader1 = Shader.Find("Standart");
        //chader2 = Shader.Find("Legacy_Shaders/Transparent/Bumped_Diffuse");

        //print(chader1.name + " " + chader2.name);


    }

    // Use this for initialization
    void Start()
    {

        TipoItem = ListaItems.Ninguno;


    }

    // Update is called once per frame
    void Update()
    {
        tiempo += Time.deltaTime;

        ///////////////////////////

        ///Hongos

        if (Encencido)
        {
            foreach (GameObject a in Particulas1)
            {
                a.SetActive(true);
            }

            foreach (GameObject a in Particulas2)
            {
                a.SetActive(false);
            }
        }

        if (!Encencido)
        {
            foreach (GameObject a in Particulas1)
            {
                a.SetActive(false);
            }

            foreach (GameObject a in Particulas2)
            {
                a.SetActive(true);
            }
        }

        ///////////////////////////

        ///Caparazones

        if (tengoCaparazon)
        {
            //transform.FindChild("Guarda_Choncha").gameObject;

            if (transform.FindChild("Guarda_Choncha").gameObject == null)
            {
                Destroy(transform.FindChild("Guarda_Choncha").gameObject);
                tengoCaparazon = false;
            }

            if (transform.FindChild("Guarda_Choncha").transform.childCount <= 0)
            {
                Destroy(transform.FindChild("Guarda_Choncha").gameObject);
                tengoCaparazon = false;

            }

            if (transform.FindChild("Guarda_Choncha").gameObject != null)
            {
                

                if (Input.GetKeyDown(KeyCode.Comma) && CaparazonRoja && !CaparazonAzul && !CaparazonVerde)
                {

                    GameObject objetivo = null;

                    GameObject CaparazonADisparar = transform.FindChild("Guarda_Choncha").transform.GetChild(0).gameObject;

                    
                    for (int i = 0; i < GameManager.Instancia.arregloPosicion.Length; i++)
                    {
                        if (GameManager.Instancia.arregloPosicion[i].name != this.gameObject.name)
                        {
                            if (GameManager.Instancia.arregloPosicion[i].GetComponent<ContadorLaps>().PosicionEnLaCarrera < transform.GetComponent<ContadorLaps>().PosicionEnLaCarrera)
                            {
                                objetivo = GameManager.Instancia.arregloPosicion[i];

                                CaparazonADisparar.gameObject.GetComponent<Script_Caparazon>().objetivo = objetivo;

                                CaparazonADisparar.transform.parent = null;
                                
                            }

                            if (objetivo == null)
                            {
                                objetivo = null;
                                CaparazonADisparar.gameObject.GetComponent<Script_Caparazon>().objetivo = objetivo;
                                CaparazonADisparar.transform.parent = null;
                                
                            }

                            ////else
                            ////{
                            ////    objetivo = null;
                            ////    CaparazonADisparar.gameObject.GetComponent<Script_Caparazon>().objetivo = objetivo;
                            ////    CaparazonADisparar.transform.parent = null;
                            ////    tiempo *= 0;




                            ////}



                        }

                       

                    }

                    /*
                    if(CaparazonADisparar.transform.parent == null && objetivo == null)
                    {
                        CaparazonADisparar.AddComponent<Rigidbody>();
                        CaparazonADisparar.GetComponent<Rigidbody>().constraints = RigidbodyConstraints.FreezeRotationX | RigidbodyConstraints.FreezeRotationZ;

                    }
                    */




                }


                if (Input.GetKeyDown(KeyCode.Comma) && CaparazonVerde && !CaparazonRoja && !CaparazonAzul)
                {

                    GameObject objetivo = null;

                    GameObject CaparazonADisparar = transform.FindChild("Guarda_Choncha").transform.GetChild(0).gameObject;

                    CaparazonADisparar.AddComponent<Rigidbody>();
                    CaparazonADisparar.GetComponent<Rigidbody>().constraints = RigidbodyConstraints.FreezeRotationX | RigidbodyConstraints.FreezeRotationZ;

                    transform.FindChild("Guarda_Choncha").transform.GetChild(0).gameObject.GetComponent<Script_Caparazon>().objetivo = objetivo;

                    CaparazonADisparar.transform.parent = null;

                    
                }


                if ( CaparazonAzul && !CaparazonRoja && !CaparazonVerde)
                {
                    GameObject objetivo = null;

                    GameObject CaparazonADisparar = transform.FindChild("Guarda_Choncha").transform.GetChild(0).gameObject;


                    for (int i = 0; i < GameManager.Instancia.arregloPosicion.Length; i++)
                    {
                        objetivo = GameManager.Instancia.arregloPosicion[0];

                        //if (GameManager.Instancia.arregloPosicion[i].name == this.gameObject.name)
                        //{
                        //    if (i != 0)
                        //    {
                        //        objetivo = GameManager.Instancia.arregloPosicion[i - 1];

                        //    }

                        //    if (i == 0)
                        //    {
                        //        objetivo = GetComponent<Comp_Dos>().objetivoSeguir.gameObject;
                        //        CaparazonADisparar.AddComponent<Rigidbody>();

                        //    }
                        //}
                    }




                    transform.FindChild("Guarda_Choncha").transform.GetChild(0).gameObject.GetComponent<Script_Caparazon>().objetivo = objetivo;



                    CaparazonADisparar.transform.parent = null;

                    
                }
            }

            


        }

        ///////////////////////////

        ///Estrella
        if (TengoEstrella)
        {


           
            float VelOrg2 = velocidadOriginal;

            Atributos.velocidad = VelOrg2 + 1.05f;



            float Rand1 = Random.Range(0f, 1f);
            float Rand2 = Random.Range(0f, 1f);
            float Rand3 = Random.Range(0f, 1f);


            Color colorRand = new Color(Rand1, Rand2, Rand3);


            MeshRenderer[] renderizador = GetComponentsInChildren<MeshRenderer>();

            for (int i = 0; i < renderizador.Length; i++)
            {
                renderizador[i].material.color = colorRand;
                // renderizador[i].material.SetColor("_Color", colorRand);
            }


            contador++;

            // Ojo multiplicar 24 * la cantidad de segundos que desees la duracion ya que 24 frames son un segundo





            if (contador >= 192)
            {
                TengoEstrella = false;
                Atributos.velocidad = velocidadOriginal;


                contador = 0;





            }



            //if(TipoItem == ListaItems.Ninguno)
            //{
            //    TengoEstrella = false;
            //}
        }

        if (!TengoEstrella)
        {


            for (int i = 0; i < MeshOriginal.Length; i++)
            {
                 MeshOriginal[i].material.color = ColorOriginal[i];
                // renderizador[i].material.SetColor("_Color", colorRand);
            }

        }


        ////////////////////////////////

        /// Fantasma

        if (TengoFantasma)
        {
            //Transparencia

            contador++;

            if (contador >= 84)
            {
            
                TengoFantasma = false;
                contador = 0;
                if (TipoItem == ListaItems.Fantasma)
                {
                    TipoItem = ListaItems.Ninguno;

                }



            }



            MeshRenderer[] renderizador = null;

            transparencia -= Time.deltaTime;

            if (transparencia <= 0)
            {
                transparencia = 0;
            }

            for (int i = 0; i <= transform.GetChild(0).childCount; i++)
            {
                renderizador = transform.GetChild(0).GetComponentsInChildren<MeshRenderer>();
                Color alpha = new Color(renderizador[i].material.color.r, renderizador[i].material.color.b, renderizador[i].material.color.b, transparencia);
                renderizador[i].material.color = alpha;
                renderizador[i].material.shader = chader1;

                // Legacy_Shaders/Transparent/Bumped_Diffuse

            }


        }


        if (!TengoFantasma) //&& TipoItem != ListaItems.Super_Hongo && TipoItem != ListaItems.Un_Hongo && TipoItem != ListaItems.Tres_Hongos && !TengoEstrella && !EstoyChico)
        {
            //Transparencia
            
            MeshRenderer[] renderizador = null;

            transparencia += Time.deltaTime;

            if (transparencia >= 1)
            {
                transparencia = 1;
            }

            for (int i = 0; i <= transform.GetChild(0).childCount ; i++)
            {
                renderizador = transform.GetChild(0).GetComponentsInChildren<MeshRenderer>();
                Color alpha = new Color(renderizador[i].material.color.r, renderizador[i].material.color.b, renderizador[i].material.color.b, transparencia);
                renderizador[i].material.color = alpha;

                if (transparencia >= .8f)
                {
                    renderizador[i].material.shader = chaderOriginal;
                }
                
                //print(renderizador[i].material.shader.name);
                //print(renderizador[i].name);

            }


        }

        //// Racimo

        if (tengoRacimo)
        {
            vacioPlatano.SetActive(true);

            


            for (int i = 0; i < hijos; i++)
            {
                vacioPlatano.transform.GetChild(i).GetChild(0).transform.position = vacioPlatano.transform.GetChild(i).transform.position;
               
                
            }


            if (Input.GetKeyDown(KeyCode.Comma))
            {


                //transform.FindChild("Guarda_Platano").GetChild(hijos - 1).parent = null;
                vacioPlatano.transform.GetChild(hijos-1).GetChild(0).parent = null;

                hijos--;

                

                if (hijos <= 1)
                {
                    vacioPlatano.SetActive(false);
                    //Destroy(transform.FindChild("Guarda_Platano").gameObject);
                    tengoRacimo = false;
                }


            }

            //if (transform.FindChild("Guarda_Platano").parent == null)
            //{
            //    tengoRacimo = false;
            //}
        }

        if (!tengoRacimo)
        {
            hijos = 6;

            vacioPlatano.SetActive(false);


            //GameObject PadreRacimo = GameObject.Find("Guarda_Platano");

            //if (PadreRacimo != null && PadreRacimo.transform.parent == null)
            //{
            //    for (int i = 0; i < PadreRacimo.transform.childCount; i++)
            //    {
            //        float weaRandom = Random.Range(-50f, 50f);
            //        PadreRacimo.transform.GetChild(i).transform.Translate(new Vector3(weaRandom, 0, weaRandom) * Time.deltaTime);
            //        PadreRacimo.transform.GetChild(i).parent = null;
            //    }

            //}

            
        }

        if(EstoyChico)
        {
            contador++;


            if (contador >= 124)
            {
                EstoyChico = false;
                //    contador = 0;
                //    GameObject PadreProvicional = this.gameObject.transform.parent.gameObject;
                //    PadreProvicional.transform.localScale = new Vector3(1, 1, 1);

            }
        }

        if(!EstoyChico)
        {
            transform.localScale = new Vector3(1, 1, 1);
            //if (transform.parent != null || transform.localScale != Vector3.one)
            //{
            //    GameObject PadreProvicional = this.gameObject.transform.parent.gameObject;
            //    transform.parent = null;
            //    Vector3 pos = transform.position;

            //    transform.position = pos;




            //    Destroy(PadreProvicional);

            //    Atributos.velocidad = velocidadOriginal;
            //}
        }

        ////////////////////////


        switch (TipoItem)
        {
            case ListaItems.Ninguno:
                // print("no hay item");
                break;

            case ListaItems.Banana:
                BananaItem();
                //print("tienes una banana");
                break;

            case ListaItems.Un_Hongo:

                limiteContador = 1;

                Hongo();
                //print("tienes un hongo");
                break;

            case ListaItems.Falsa_Caja_Item:
                FakeBoxItem();
                //print("tienes una caja falsa");
                break;

            case ListaItems.Caparazon_Verde:

                NumeroCaparazon = 1;
                CaparazonRoja = false;
                CaparazonAzul = false;
                CaparazonVerde = true;

                Caparazones();

                //print("tienes un caparazon verde");
                break;

            case ListaItems.Caparazon_Rojo:

                NumeroCaparazon = 1;
                CaparazonRoja = true;
                CaparazonAzul = false;
                CaparazonVerde = false;

                Caparazones();

                //print("tienes un caparazon rojo");
                break;

            case ListaItems.Tres_Caparazones_Rojos:

                NumeroCaparazon = 3;
                CaparazonRoja = true;
                CaparazonAzul = false;
                CaparazonVerde = false;

                Caparazones();

                //print("tienes tres caparazones rojos");
                break;

            case ListaItems.Tres_Caparazones_Verdes:

                NumeroCaparazon = 3;
                CaparazonRoja = false;
                CaparazonAzul = false;
                CaparazonVerde = true;

                Caparazones();
                //print("tienes tres caparazones verdes");
                break;

            case ListaItems.Super_Hongo:

                limiteContador = 5;

                Hongo();

                //print("tienes super hongo");
                break;

            case ListaItems.Tres_Hongos:


                limiteContador = 3;

                Hongo();


                // print("tienes tres hongos");
                break;

            case ListaItems.Estrella:




                EstrellaItem();
                // print("tienes una estrella");
                break;

            case ListaItems.Racimo_Bananas:

                RacimoItem();
                // print("tienes un racimo");
                break;

            case ListaItems.Caparazon_Azul:

                NumeroCaparazon = 1;
                CaparazonAzul = true;
                CaparazonRoja = false;
                CaparazonVerde = false;

                Caparazones();

                // print("tienes un caparazon azul");
                break;

            case ListaItems.Rayo:
                RayoItem();
                // print("tienes un rayo");
                break;

            case ListaItems.Fantasma:
                FantasmaItem();
                //print("tienes un fantasma");
                break;


        }

    }

    void BananaItem()
    {
        if (Input.GetKeyDown(KeyCode.Comma) && !tengoCaparazon && !tengoRacimo)
        {
            //La linea de abajo es para mantenerlo pegado a ti
            //GameObject platano = Instantiate(TodoslosItems.arregloItems[0], new Vector3(transform.localPosition.x, transform.localPosition.y -.25f, transform.localPosition.z + .5f), Quaternion.identity, transform) as GameObject;
            GameObject platano = Instantiate(TodoslosItems.arregloItems[0], new Vector3(transform.localPosition.x, transform.localPosition.y - .25f, transform.localPosition.z + .5f), Quaternion.identity) as GameObject;
            platano.transform.localScale = new Vector3(1, 1, 1);
            TipoItem = ListaItems.Ninguno;
        }



    }

    void RacimoItem()
    {
        //La linea de abajo es para mantenerlo pegado a ti
        //GameObject platano = Instantiate(TodoslosItems.arregloItems[0], new Vector3(transform.localPosition.x, transform.localPosition.y -.25f, transform.localPosition.z + .5f), Quaternion.identity, transform) as GameObject;

        if (Input.GetKeyDown(KeyCode.Comma) && !tengoCaparazon && !tengoRacimo)
        {

            if (!tengoRacimo && !tengoCaparazon && !TengoFantasma && !TengoEstrella)
            {
                tengoRacimo = true;

                for (int i = 0; i < vacioPlatano.transform.childCount; i++)
                {
                    Instantiate(TodoslosItems.arregloItems[0], vacioPlatano.transform.GetChild(i).transform.position, vacioPlatano.transform.GetChild(i).transform.rotation, vacioPlatano.transform.GetChild(i).transform);
                }

                /*

                GameObject platano = Instantiate(TodoslosItems.arregloItems[0], vacioPlatano.transform.GetChild(0).transform.position, vacioPlatano.transform.GetChild(0).transform.rotation, vacioPlatano.transform.GetChild(0).transform) as GameObject;
                GameObject platano2 = Instantiate(TodoslosItems.arregloItems[0], vacioPlatano.transform.GetChild(1).transform.position, vacioPlatano.transform.GetChild(1).transform.rotation, vacioPlatano.transform.GetChild(1).transform) as GameObject;
                GameObject platano3 = Instantiate(TodoslosItems.arregloItems[0], vacioPlatano.transform.GetChild(2).transform.position, vacioPlatano.transform.GetChild(2).transform.rotation, vacioPlatano.transform.GetChild(2).transform) as GameObject;
                GameObject platano4 = Instantiate(TodoslosItems.arregloItems[0], vacioPlatano.transform.GetChild(3).transform.position, vacioPlatano.transform.GetChild(3).transform.rotation, vacioPlatano.transform.GetChild(3).transform) as GameObject;
                GameObject platano5 = Instantiate(TodoslosItems.arregloItems[0], vacioPlatano.transform.GetChild(4).transform.position, vacioPlatano.transform.GetChild(4).transform.rotation, vacioPlatano.transform.GetChild(4).transform) as GameObject;
                GameObject platano6 = Instantiate(TodoslosItems.arregloItems[0], vacioPlatano.transform.GetChild(5).transform.position, vacioPlatano.transform.GetChild(5).transform.rotation, vacioPlatano.transform.GetChild(4).transform) as GameObject;
                */
                foreach (Transform a in vacioPlatano.transform)
                {
                    a.transform.localScale = new Vector3(1, 1, 1);
                }

                //platano.transform.localScale = new Vector3(1, 1, 1);
                TipoItem = ListaItems.Ninguno;

            }
        }


        if(tengoRacimo && TipoItem == ListaItems.Racimo_Bananas)
        {
            TipoItem = ListaItems.Racimo_Bananas;
        }


        
    }


    void Hongo()
    {
        if (Input.GetKeyDown(KeyCode.Comma) && !tengoCaparazon && !tengoRacimo)
        {

            if (tiempo > 2 && contador < limiteContador && !tengoCaparazon && !TengoEstrella && !TengoFantasma && !tengoRacimo)
            {
                tiempo *= 0;
                StartCoroutine(VolverAVelocidadNormal());
                contador++;
                ValorHongos = contador;

            }

            if (contador >= limiteContador && !TengoFantasma)
            {
                TipoItem = ListaItems.Ninguno;
                contador = 0;
                ValorHongos = contador;
            }

        }

        

        
    }



    IEnumerator VolverAVelocidadNormal()
    {

        Atributos.velocidad *= 1.2f;
        Encencido = true;

        yield return new WaitForSecondsRealtime(.8f);

        Atributos.velocidad = velocidadOriginal;
        Encencido = false;

    }

    void FakeBoxItem()
    {
        //La linea de abajo es para mantenerlo pegado a ti
        //GameObject platano = Instantiate(TodoslosItems.arregloItems[0], new Vector3(transform.localPosition.x, transform.localPosition.y -.25f, transform.localPosition.z + .5f), Quaternion.identity, transform) as GameObject;

        if (Input.GetKeyDown(KeyCode.Comma) && !tengoCaparazon && !tengoRacimo)
        {
            GameObject Caja = Instantiate(TodoslosItems.arregloItems[2], new Vector3(transform.localPosition.x, transform.localPosition.y, transform.localPosition.z + .5f), Quaternion.identity) as GameObject;
            //platano.transform.localScale = new Vector3(1, 1, 1);
            TipoItem = ListaItems.Ninguno;
        }


    }

    void Caparazones()
    {
        if (NumeroCaparazon == 3 && CaparazonRoja && !CaparazonAzul && !tengoCaparazon && !CaparazonVerde && !TengoEstrella && !TengoFantasma && !tengoRacimo)
        {
            if (Input.GetKeyDown(KeyCode.Comma) && !tengoCaparazon && !tengoRacimo)
            {
                GameObject vacio = new GameObject("Guarda_Choncha");

                vacio.transform.localPosition = this.transform.localPosition;

                vacio.transform.parent = this.transform;

                GameObject Caparazon1 = Instantiate(TodoslosItems.arregloItems[3], new Vector3(transform.localPosition.x, transform.localPosition.y, transform.localPosition.z + .77f), Quaternion.identity, vacio.transform) as GameObject;
                GameObject Caparazon2 = Instantiate(TodoslosItems.arregloItems[3], new Vector3(transform.localPosition.x + .7f, transform.localPosition.y, transform.localPosition.z - .5f), Quaternion.identity, vacio.transform) as GameObject;
                GameObject Caparazon3 = Instantiate(TodoslosItems.arregloItems[3], new Vector3(transform.localPosition.x - .7f, transform.localPosition.y, transform.localPosition.z - .5f), Quaternion.identity, vacio.transform) as GameObject;

                if (vacio.transform.childCount > 0)
                {
                    tengoCaparazon = true;

                }





                //Caparazon1.GetComponent<Script_Caparazon>().ObjetoSeguir = this.gameObject;
                //Caparazon2.GetComponent<Script_Caparazon>().ObjetoSeguir = this.gameObject;
                //Caparazon3.GetComponent<Script_Caparazon>().ObjetoSeguir = this.gameObject;

                NumeroCaparazon = 0;


                TipoItem = ListaItems.Ninguno;
            }

           
        }

        if (NumeroCaparazon == 1 && CaparazonRoja && !CaparazonAzul && !tengoCaparazon && !CaparazonVerde && !TengoEstrella && !TengoFantasma && !tengoRacimo)
        {
            if (Input.GetKeyDown(KeyCode.Comma) && !tengoCaparazon && !tengoRacimo)
            {

                GameObject vacio = new GameObject("Guarda_Choncha");

                vacio.transform.localPosition = this.transform.localPosition;

                vacio.transform.parent = this.transform;

                GameObject Caparazon1 = Instantiate(TodoslosItems.arregloItems[3], new Vector3(transform.localPosition.x, transform.localPosition.y, transform.localPosition.z + .77f), Quaternion.identity, vacio.transform) as GameObject;

                if (vacio.transform.childCount > 0)
                {
                    tengoCaparazon = true;

                }


                NumeroCaparazon = 0;


                TipoItem = ListaItems.Ninguno;
            }
        }


        if (NumeroCaparazon == 3 && !CaparazonRoja && !CaparazonAzul && !tengoCaparazon && CaparazonVerde && !TengoEstrella && !TengoFantasma && !tengoRacimo)
        {
            if (Input.GetKeyDown(KeyCode.Comma) && !tengoCaparazon && !tengoRacimo)
            {

                GameObject vacio = new GameObject("Guarda_Choncha");

                vacio.transform.localPosition = this.transform.localPosition;

                vacio.transform.parent = this.transform;

                GameObject Caparazon1 = Instantiate(TodoslosItems.arregloItems[1], new Vector3(transform.localPosition.x, transform.localPosition.y, transform.localPosition.z + .77f), Quaternion.identity, vacio.transform) as GameObject;
                GameObject Caparazon2 = Instantiate(TodoslosItems.arregloItems[1], new Vector3(transform.localPosition.x + .7f, transform.localPosition.y, transform.localPosition.z - .5f), Quaternion.identity, vacio.transform) as GameObject;
                GameObject Caparazon3 = Instantiate(TodoslosItems.arregloItems[1], new Vector3(transform.localPosition.x - .7f, transform.localPosition.y, transform.localPosition.z - .5f), Quaternion.identity, vacio.transform) as GameObject;

                if (vacio.transform.childCount > 0)
                {
                    tengoCaparazon = true;

                }





                //Caparazon1.GetComponent<Script_Caparazon>().ObjetoSeguir = this.gameObject;
                //Caparazon2.GetComponent<Script_Caparazon>().ObjetoSeguir = this.gameObject;
                //Caparazon3.GetComponent<Script_Caparazon>().ObjetoSeguir = this.gameObject;

                NumeroCaparazon = 0;


                TipoItem = ListaItems.Ninguno;
            }
        }

        if (NumeroCaparazon == 1 && !CaparazonRoja && !CaparazonAzul && !tengoCaparazon && CaparazonVerde && !TengoEstrella && !TengoFantasma && !tengoRacimo)
        {
            if (Input.GetKeyDown(KeyCode.Comma) && !tengoCaparazon && !tengoRacimo)
            {

                GameObject vacio = new GameObject("Guarda_Choncha");

                vacio.transform.localPosition = this.transform.localPosition;

                vacio.transform.parent = this.transform;

                GameObject Caparazon1 = Instantiate(TodoslosItems.arregloItems[1], new Vector3(transform.localPosition.x, transform.localPosition.y, transform.localPosition.z + .77f), Quaternion.identity, vacio.transform) as GameObject;

                if (vacio.transform.childCount > 0)
                {
                    tengoCaparazon = true;

                }


                NumeroCaparazon = 0;


                TipoItem = ListaItems.Ninguno;
            }
        }


        if (NumeroCaparazon == 1 && CaparazonAzul && !CaparazonRoja && !tengoCaparazon && !CaparazonVerde && !TengoEstrella && !TengoFantasma && !tengoRacimo)
        {

            if (Input.GetKeyDown(KeyCode.Comma) && !tengoCaparazon && !tengoRacimo)
            {

                GameObject vacio = new GameObject("Guarda_Choncha");

                vacio.transform.localPosition = this.transform.localPosition;

                vacio.transform.parent = this.transform;

                GameObject Caparazon1 = Instantiate(TodoslosItems.arregloItems[4], new Vector3(transform.localPosition.x, transform.localPosition.y, transform.localPosition.z + .77f), Quaternion.identity, vacio.transform) as GameObject;

                if (vacio.transform.childCount > 0)
                {
                    tengoCaparazon = true;

                }


                NumeroCaparazon = 0;


                TipoItem = ListaItems.Ninguno;
            }
        }

    }

    void EstrellaItem()
    {
        if (Input.GetKeyDown(KeyCode.Comma) && !tengoCaparazon && !tengoRacimo)
        {
            contador = 0;
            TengoEstrella = true;
            TipoItem = ListaItems.Ninguno;

        }


    }

    void FantasmaItem()
    {
        if (Input.GetKeyDown(KeyCode.Comma) && !tengoCaparazon && !tengoRacimo)
        {
            int PersonajeRobar = Random.Range(0, GameManager.Instancia.arregloPosicion.Length);

            ////float duration = 5;

            ////MeshRenderer renderizador = GetComponent<MeshRenderer>();

            ////Color colorStart = renderizador.material.color;
            ////Color colorEnd = new Color(renderizador.material.color.r, renderizador.material.color.g, renderizador.material.color.b, 0.0f);

            ////for (float t = 0.0f; t < duration; t += Time.deltaTime)
            ////{
            ////    renderizador.material.color = Color.Lerp(colorStart, colorEnd, t / duration);

            ////}

            TengoFantasma = true;


            MeshRenderer[] renderizador = GetComponentsInChildren<MeshRenderer>();



            for (int i = 0; i < GameManager.Instancia.arregloPosicion.Length; i++)
            {



                if (GameManager.Instancia.arregloPosicion[PersonajeRobar].name != this.gameObject.name)
                {
                    if (GameManager.Instancia.arregloPosicion[PersonajeRobar].GetComponent<Agarre_Item>().TipoItem != 0)
                    {
                        TipoItem = (Item_Personaje.ListaItems)GameManager.Instancia.arregloPosicion[PersonajeRobar].GetComponent<Agarre_Item>().TipoItem;
                        GameManager.Instancia.arregloPosicion[PersonajeRobar].GetComponent<Agarre_Item>().TipoItem = (Agarre_Item.ListaItems)ListaItems.Ninguno;


                    }




                }

                if (GameManager.Instancia.arregloPosicion[PersonajeRobar].name == this.gameObject.name)
                {
                    PersonajeRobar = Random.Range(0, GameManager.Instancia.arregloPosicion.Length);
                }


            }


            //if(contador >= 120)
            //{

            //    TengoFantasma = false;

            //    if (TipoItem == ListaItems.Fantasma)
            //    {
            //        TipoItem = ListaItems.Ninguno;

            //    }



            //}
        }
    }

    void RayoItem()
    {


        if (Input.GetKeyDown(KeyCode.Comma) && !tengoCaparazon && !tengoRacimo)
        {

            for (int i = 0; i < GameManager.Instancia.arregloPosicion.Length; i++)
            {


                if (GameManager.Instancia.arregloPosicion[i].name != this.gameObject.name && GameManager.Instancia.arregloPosicion[i].GetComponent<Agarre_Item>().TipoItem != (Agarre_Item.ListaItems)ListaItems.Estrella)
                {



                    GameManager.Instancia.arregloPosicion[i].GetComponent<Agarre_Item>().transform.localScale = new Vector3(.5f, .5f, .5f);
                    GameManager.Instancia.arregloPosicion[i].GetComponent<Agarre_Item>().TipoItem = (Agarre_Item.ListaItems)ListaItems.Ninguno;
                    GameManager.Instancia.arregloPosicion[i].GetComponent<Agarre_Item>().EstoyChico = true;
                    GameManager.Instancia.arregloPosicion[i].GetComponent<Comp_Dos>().velocidad = GameManager.Instancia.arregloPosicion[i].GetComponent<Comp_Dos>().velocidad / 2;


                    if (GameManager.Instancia.arregloPosicion[i].GetComponent<Agarre_Item>().tengoRacimo)
                    {
                        int hijosContrincante = GameManager.Instancia.arregloPosicion[i].transform.FindChild("Guarda_Platano").childCount;

                        for (int j = 0; j <= hijosContrincante - 1; j++)
                        {
                            float weaRandom = Random.Range(-50f, 50f);
                            GameManager.Instancia.arregloPosicion[i].transform.FindChild("Guarda_Platano").GetChild(j).GetChild(0).transform.Translate(new Vector3(weaRandom, 0, weaRandom) * Time.deltaTime);

                            GameManager.Instancia.arregloPosicion[i].transform.FindChild("Guarda_Platano").GetChild(j).GetChild(0).transform.parent = null;
                            GameManager.Instancia.arregloPosicion[i].GetComponent<Agarre_Item>().tengoRacimo = false;


                        }
                    }


                    TipoItem = ListaItems.Ninguno;
                    //if (GameManager.Instancia.arregloPosicion[i].GetComponent<Agarre_Item>().TipoItem != 0)
                    //{

                    //    GameManager.Instancia.arregloPosicion[i].GetComponent<Agarre_Item>().TipoItem = ListaItems.Ninguno;
                    //    


                    //}




                }

                if (GameManager.Instancia.arregloPosicion[i].GetComponent<Agarre_Item>().TipoItem == (Agarre_Item.ListaItems)ListaItems.Estrella)
                {
                    TipoItem = ListaItems.Ninguno;

                }
            }
        }

        
        


    }
}

