﻿using UnityEngine;
using System.Collections;

public class RandomdeItem : MonoBehaviour {

    Agarre_Item itemagarrado;
    Item_Personaje itemagarradoPj;
	// Use this for initialization
	void Start () {
	
	}
	
	// Update is called once per frame
	void OnTriggerEnter (Collider col)
    {
        if (col.gameObject.tag == "CPU")
        {

            itemagarrado = col.gameObject.GetComponent<Agarre_Item>();

            if (itemagarrado.TipoItem == 0)
            {
                itemagarrado.TipoItem = (Agarre_Item.ListaItems)Random.Range(1, 15);
            }


        }

        if (col.gameObject.tag == "Player")
        {

            itemagarradoPj = col.gameObject.GetComponent<Item_Personaje>();

            if (itemagarradoPj.TipoItem == 0)
            {
                itemagarradoPj.TipoItem = (Item_Personaje.ListaItems)Random.Range(1, 15);
            }


        }

    }
}
