﻿using UnityEngine;
using System.Collections;
using UnityEngine.UI;

public class Calcular_posicion : MonoBehaviour {

    Posicion_de_seguido pos;
    ContadorLaps[] CPU_Players;
    int ContadorPosiciones;

    public Image Lugar1;
    public Image Lugar2;
    public Image Lugar3;
    // Use this for initialization
    void Start()
    {

        pos = GameObject.FindObjectOfType<Posicion_de_seguido>();

        CPU_Players = FindObjectsOfType(typeof(ContadorLaps)) as ContadorLaps[];

        
        //Comps_Players = new GameObject[GameObject.FindObjectsOfType<Posicion_de_seguido>().Length];

        //for (int i = 0; i < GameObject.FindObjectsOfType<Posicion_de_seguido>().Length; i++)
        //{
        //    Comps_Players[i] = GameObject.FindObjectsOfType<Posicion_de_seguido>();
        //}





    }

    // Update is called once per frame
    void Update()
    {
        //foreach (ContadorLaps a in CPU_Players)
        //{
        //    float distancia = Vector3.Distance(a.transform.position, transform.position);

        //    a.DistanciaPersonal = distancia;

        //    if (distancia <= 5f && ContadorPosiciones < pos.posiciones.Length)
        //    {
        //        ContadorPosiciones++;
        //    }

        //    if (ContadorPosiciones >= pos.posiciones.Length)
        //    {
        //        ContadorPosiciones = 0;
        //    }
        //}

        for(int i = 0; i < CPU_Players.Length; i++)
        {
            float distancia = Vector3.Distance(CPU_Players[i].transform.position, transform.position);

            CPU_Players[i].DistanciaPersonal = distancia;

            if (distancia <= 5f && ContadorPosiciones < pos.posiciones.Length)
            {
                ContadorPosiciones++;
            }

            if (ContadorPosiciones >= pos.posiciones.Length)
            {
                ContadorPosiciones = 0;
            }
        }

        transform.position = pos.posiciones[ContadorPosiciones].transform.position;


        float distancia0 = CPU_Players[0].DistanciaPersonal;//Vector3.Distance(CPU_Players[0].transform.position, transform.position);
        float distancia1 = CPU_Players[1].DistanciaPersonal;//Vector3.Distance(CPU_Players[1].transform.position, transform.position);
        float distancia2 = CPU_Players[2].DistanciaPersonal;//Vector3



        //int posCPU1 = CPU_Players[0].GetComponent<Posicion_de_seguido>().pos;
        //int posCPU2 = CPU_Players[1].GetComponent<Posicion_de_seguido>().pos;


        if (CPU_Players[0].vueltas > CPU_Players[1].vueltas && CPU_Players[0].vueltas > CPU_Players[2].vueltas)
        {
            ObtenPrimerlugar0();
            if (CPU_Players[1].vueltas > CPU_Players[2].vueltas)
            {
                ObtenSegundolugar1();
                ObtenTercerlugar2();
            }

            else if (CPU_Players[2].vueltas > CPU_Players[1].vueltas)
            {
                ObtenSegundolugar2();
                ObtenTercerlugar1();
            }

            else if (CPU_Players[2].vueltas == CPU_Players[1].vueltas)
            {
                if (distancia1 > distancia2)
                {
                    ObtenSegundolugar2();
                    ObtenTercerlugar1();
                }

                else if (distancia1 < distancia2)
                {
                    ObtenSegundolugar1();
                    ObtenTercerlugar2();
                }
            }
        }


        if (CPU_Players[1].vueltas > CPU_Players[0].vueltas && CPU_Players[1].vueltas > CPU_Players[2].vueltas)
        {
            ObtenPrimerlugar1();
            if (CPU_Players[0].vueltas > CPU_Players[2].vueltas)
            {
                ObtenSegundolugar0();
                ObtenTercerlugar2();
            }

            else if (CPU_Players[2].vueltas > CPU_Players[0].vueltas)
            {
                ObtenSegundolugar2();
                ObtenTercerlugar0();
            }

            else if (CPU_Players[2].vueltas == CPU_Players[0].vueltas)
            {
                if (distancia0 > distancia2)
                {
                    ObtenSegundolugar2();
                    ObtenTercerlugar0();
                }

                else if (distancia0 < distancia2)
                {
                    ObtenSegundolugar0();
                    ObtenTercerlugar2();
                }
            }
        }

        if (CPU_Players[2].vueltas > CPU_Players[0].vueltas && CPU_Players[2].vueltas > CPU_Players[1].vueltas)
        {
            ObtenPrimerlugar2();
            if (CPU_Players[0].vueltas > CPU_Players[1].vueltas)
            {
                ObtenSegundolugar0();
                ObtenTercerlugar1();
            }

            else if (CPU_Players[1].vueltas > CPU_Players[0].vueltas)
            {
                ObtenSegundolugar1();
                ObtenTercerlugar0();
            }

            else if (CPU_Players[1].vueltas == CPU_Players[0].vueltas)
            {
                if (distancia0 > distancia1)
                {
                    ObtenSegundolugar1();
                    ObtenTercerlugar0();
                }

                else if (distancia0 < distancia1)
                {
                    ObtenSegundolugar0();
                    ObtenTercerlugar1();
                }
            }
        }


        if (CPU_Players[0].vueltas == CPU_Players[1].vueltas && CPU_Players[0].vueltas == CPU_Players[2].vueltas)
        {

            if(!CPU_Players[0].check1 && !CPU_Players[1].check1 && !CPU_Players[2].check1 || CPU_Players[0].check1 && CPU_Players[1].check1 && CPU_Players[2].check1 || CPU_Players[0].check2 && CPU_Players[1].check2 && CPU_Players[2].check2 || CPU_Players[0].check3 && CPU_Players[1].check3 && CPU_Players[2].check3)
            {
                if (distancia0 < distancia1 && distancia1 < distancia2)
                {
                    ObtenPrimerlugar0();
                    ObtenSegundolugar1();
                    ObtenTercerlugar2();
                }

                if (distancia0 < distancia1 && distancia1 > distancia2)
                {
                    ObtenPrimerlugar0();
                    ObtenSegundolugar2();
                    ObtenTercerlugar1();
                }

                if (distancia1 < distancia0 && distancia0 < distancia2)
                {
                    ObtenPrimerlugar1();
                    ObtenSegundolugar0();
                    ObtenTercerlugar2();
                }

                if (distancia1 < distancia0 && distancia0 > distancia2)
                {
                    ObtenPrimerlugar1();
                    ObtenSegundolugar2();
                    ObtenTercerlugar0();
                }

                if (distancia2 < distancia0 && distancia0 < distancia1)
                {
                    ObtenPrimerlugar2();
                    ObtenSegundolugar0();
                    ObtenTercerlugar1();
                }

                if (distancia2 < distancia0 && distancia0 > distancia1)
                {
                    ObtenPrimerlugar2();
                    ObtenSegundolugar1();
                    ObtenTercerlugar0();
                }
            }

            ////////////////////////////////////////////////////////////////
            if (CPU_Players[0].check1 && !CPU_Players[1].check1 && !CPU_Players[2].check1)
            {
                if (distancia1 < distancia2)
                {
                    ObtenPrimerlugar0();
                    ObtenSegundolugar1();
                    ObtenTercerlugar2();
                }


                if (distancia2 < distancia1)
                {
                    ObtenPrimerlugar0();
                    ObtenSegundolugar2();
                    ObtenTercerlugar1();
                }
            }



            if (CPU_Players[0].check1 && CPU_Players[1].check1 && !CPU_Players[2].check1)
            {
                if (distancia0 < distancia1)
                {
                    ObtenPrimerlugar0();
                    ObtenSegundolugar1();
                    ObtenTercerlugar2();
                }


                if (distancia1 < distancia0)
                {
                    ObtenPrimerlugar1();
                    ObtenSegundolugar0();
                    ObtenTercerlugar2();
                }
            }

            //////////////////////////////////////////////////////////////////////////////

            if (CPU_Players[0].check2 && !CPU_Players[1].check2 && !CPU_Players[2].check2)
            {
                if (distancia1 < distancia2)
                {
                    ObtenPrimerlugar0();
                    ObtenSegundolugar1();
                    ObtenTercerlugar2();
                }


                if (distancia2 < distancia1)
                {
                    ObtenPrimerlugar0();
                    ObtenSegundolugar2();
                    ObtenTercerlugar1();
                }
            }



            if (CPU_Players[0].check2 && CPU_Players[1].check2 && !CPU_Players[2].check2)
            {
                if (distancia0 < distancia1)
                {
                    ObtenPrimerlugar0();
                    ObtenSegundolugar1();
                    ObtenTercerlugar2();
                }


                if (distancia1 < distancia0)
                {
                    ObtenPrimerlugar1();
                    ObtenSegundolugar0();
                    ObtenTercerlugar2();
                }
            }

            //////////////////////////////////////////////////////////////////////////////////

            if (CPU_Players[0].check3 && !CPU_Players[1].check3 && !CPU_Players[2].check3)
            {
                if (distancia1 < distancia2)
                {
                    ObtenPrimerlugar0();
                    ObtenSegundolugar1();
                    ObtenTercerlugar2();
                }


                if (distancia2 < distancia1)
                {
                    ObtenPrimerlugar0();
                    ObtenSegundolugar2();
                    ObtenTercerlugar1();
                }
            }



            if (CPU_Players[0].check3 && CPU_Players[1].check3 && !CPU_Players[2].check3)
            {
                if (distancia0 < distancia1)
                {
                    ObtenPrimerlugar0();
                    ObtenSegundolugar1();
                    ObtenTercerlugar2();
                }


                if (distancia1 < distancia0)
                {
                    ObtenPrimerlugar1();
                    ObtenSegundolugar0();
                    ObtenTercerlugar2();
                }
            }

            ////////////////////////////////////////////////////////////////////////////////////////////////////////////

            if (CPU_Players[1].check1 && !CPU_Players[0].check1 && !CPU_Players[2].check1)
            {
                if (distancia0 < distancia2)
                {
                    ObtenPrimerlugar1();
                    ObtenSegundolugar0();
                    ObtenTercerlugar2();
                }


                if (distancia2 < distancia1)
                {
                    ObtenPrimerlugar1();
                    ObtenSegundolugar2();
                    ObtenTercerlugar0();
                }
            }



            if (CPU_Players[1].check1 && CPU_Players[0].check1 && !CPU_Players[2].check1)
            {
                if (distancia0 < distancia1)
                {
                    ObtenPrimerlugar0();
                    ObtenSegundolugar1();
                    ObtenTercerlugar2();
                }


                if (distancia1 < distancia0)
                {
                    ObtenPrimerlugar1();
                    ObtenSegundolugar0();
                    ObtenTercerlugar2();
                }
            }

            ///////////////////////////////////////////////////////////////////////////////////////////////


            if (CPU_Players[1].check2 && !CPU_Players[0].check2 && !CPU_Players[2].check2)
            {
                if (distancia0 < distancia2)
                {
                    ObtenPrimerlugar1();
                    ObtenSegundolugar0();
                    ObtenTercerlugar2();
                }


                if (distancia2 < distancia1)
                {
                    ObtenPrimerlugar1();
                    ObtenSegundolugar2();
                    ObtenTercerlugar0();
                }
            }



            if (CPU_Players[1].check2 && CPU_Players[0].check2 && !CPU_Players[2].check2)
            {
                if (distancia0 < distancia1)
                {
                    ObtenPrimerlugar0();
                    ObtenSegundolugar1();
                    ObtenTercerlugar2();
                }


                if (distancia1 < distancia0)
                {
                    ObtenPrimerlugar1();
                    ObtenSegundolugar0();
                    ObtenTercerlugar2();
                }
            }

            /////////////////////////////////////////////////////////////////////////////////////////////////

            if (CPU_Players[1].check3 && !CPU_Players[0].check3 && !CPU_Players[2].check3)
            {
                if (distancia0 < distancia2)
                {
                    ObtenPrimerlugar1();
                    ObtenSegundolugar0();
                    ObtenTercerlugar2();
                }


                if (distancia2 < distancia1)
                {
                    ObtenPrimerlugar1();
                    ObtenSegundolugar2();
                    ObtenTercerlugar0();
                }
            }



            if (CPU_Players[1].check3 && CPU_Players[0].check3 && !CPU_Players[2].check3)
            {
                if (distancia0 < distancia1)
                {
                    ObtenPrimerlugar0();
                    ObtenSegundolugar1();
                    ObtenTercerlugar2();
                }


                if (distancia1 < distancia0)
                {
                    ObtenPrimerlugar1();
                    ObtenSegundolugar0();
                    ObtenTercerlugar2();
                }
            }

            ////////////////////////////////////////////////////////////////////////////////////////////////////////////////
            if (CPU_Players[2].check1 && !CPU_Players[0].check1 && !CPU_Players[1].check1)
            {
                if (distancia0 < distancia1)
                {
                    ObtenPrimerlugar2();
                    ObtenSegundolugar0();
                    ObtenTercerlugar1();
                }


                if (distancia1 < distancia0)
                {
                    ObtenPrimerlugar2();
                    ObtenSegundolugar1();
                    ObtenTercerlugar0();
                }
            }



            if (CPU_Players[2].check1 && CPU_Players[0].check1 && !CPU_Players[1].check1)
            {
                if (distancia2 < distancia0)
                {
                    ObtenPrimerlugar2();
                    ObtenSegundolugar0();
                    ObtenTercerlugar1();
                }


                if (distancia0 < distancia2)
                {
                    ObtenPrimerlugar0();
                    ObtenSegundolugar2();
                    ObtenTercerlugar1();
                }
            }

            ///////////////////////////////////////////////////////////////////////////////////////////////


            if (CPU_Players[2].check2 && !CPU_Players[0].check2 && !CPU_Players[1].check2)
            {
                if (distancia0 < distancia1)
                {
                    ObtenPrimerlugar2();
                    ObtenSegundolugar0();
                    ObtenTercerlugar1();
                }


                if (distancia1 < distancia0)
                {
                    ObtenPrimerlugar2();
                    ObtenSegundolugar1();
                    ObtenTercerlugar0();
                }
            }



            if (CPU_Players[2].check2 && CPU_Players[0].check2 && !CPU_Players[1].check2)
            {
                if (distancia2 < distancia0)
                {
                    ObtenPrimerlugar2();
                    ObtenSegundolugar0();
                    ObtenTercerlugar1();
                }


                if (distancia0 < distancia2)
                {
                    ObtenPrimerlugar0();
                    ObtenSegundolugar2();
                    ObtenTercerlugar1();
                }
            }

            /////////////////////////////////////////////////////////////////////////////////////////////////

            if (CPU_Players[2].check3 && !CPU_Players[0].check3 && !CPU_Players[1].check3)
            {
                if (distancia0 < distancia1)
                {
                    ObtenPrimerlugar2();
                    ObtenSegundolugar0();
                    ObtenTercerlugar1();
                }


                if (distancia1 < distancia0)
                {
                    ObtenPrimerlugar2();
                    ObtenSegundolugar1();
                    ObtenTercerlugar0();
                }
            }



            if (CPU_Players[2].check3 && CPU_Players[0].check3 && !CPU_Players[1].check3)
            {
                if (distancia2 < distancia0)
                {
                    ObtenPrimerlugar2();
                    ObtenSegundolugar0();
                    ObtenTercerlugar1();
                }


                if (distancia0 < distancia2)
                {
                    ObtenPrimerlugar0();
                    ObtenSegundolugar2();
                    ObtenTercerlugar1();
                }
            }

            ////////////////////////////////////////////////////////////////////////////////////////////////////////////////


        }


        /*
        if (CPU_Players[0].vueltas > CPU_Players[1].vueltas)
        {
            ObtenerPrimerlugar0();
            //pos = CPU_Players[0].GetComponent<Posicion_de_seguido>();
            //print(CPU_Players[0].name + " Va en primer lugar");
        }

        else if (CPU_Players[1].vueltas > CPU_Players[0].vueltas)
        {
            ObtenerPrimerlugar1();
            //pos = CPU_Players[1].GetComponent<Posicion_de_seguido>();
            //print(CPU_Players[1].name + " Va en primer lugar");
        }

        else if(CPU_Players[0].vueltas == CPU_Players[1].vueltas)
        {
            if (posCPU1 > posCPU2)
            {
                ObtenerPrimerlugar0();
               // pos = CPU_Players[0].GetComponent<Posicion_de_seguido>();
                //print(CPU_Players[0].name + " Va en primer lugar");
            }

           else if (posCPU2 > posCPU1)
            {
                ObtenerPrimerlugar1();
               // pos = CPU_Players[1].GetComponent<Posicion_de_seguido>();
                // print(CPU_Players[1].name + " Va en primer lugar");
            }

            else if (posCPU1 == posCPU2)
            {
                if (distancia1 < distancia2)
                {
                    ObtenerPrimerlugar0();
                    //print(CPU_Players[0].name + " Va en primer lugar");
                }

                 if (distancia2 < distancia1)
                {
                    ObtenerPrimerlugar1();
                    //print(CPU_Players[1].name + " Va en primer lugar");
                }
            }

        }

        transform.position = pos.posiciones[pos.pos].transform.position;

        //if (distancia1 < distancia2 || CPU_Players[0].vueltas > CPU_Players[1].vueltas)
        //{

        //        print(CPU_Players[0].name + " Va en primer lugar");


        //}

        //else if(distancia2 < distancia1 || CPU_Players[1].vueltas > CPU_Players[0].vueltas)
        //{



        //        print(CPU_Players[1].name + " Va en primer lugar");






        //}


    }
        */

    }


    void ObtenPrimerlugar0()
    {

        CPU_Players[0].PosicionEnLaCarrera = 1;
        GameManager.Instancia.arregloPosicion[0] = CPU_Players[0].gameObject;
        Lugar1.sprite = CPU_Players[0].GetComponent<ContadorLaps>().ImagenJugador;

    }

    void ObtenPrimerlugar1()
    {

        CPU_Players[1].PosicionEnLaCarrera = 1;
        GameManager.Instancia.arregloPosicion[0] = CPU_Players[1].gameObject;
        Lugar1.sprite = CPU_Players[1].GetComponent<ContadorLaps>().ImagenJugador;

    }

    void ObtenPrimerlugar2()
    {

        CPU_Players[2].PosicionEnLaCarrera = 1;
        GameManager.Instancia.arregloPosicion[0] = CPU_Players[2].gameObject;
        Lugar1.sprite = CPU_Players[2].GetComponent<ContadorLaps>().ImagenJugador;

    }

    void ObtenSegundolugar0()
    {
        CPU_Players[0].PosicionEnLaCarrera = 2;
        GameManager.Instancia.arregloPosicion[1] = CPU_Players[0].gameObject;
        Lugar2.sprite = CPU_Players[0].GetComponent<ContadorLaps>().ImagenJugador;
    }

    void ObtenSegundolugar1()
    {

        CPU_Players[1].PosicionEnLaCarrera = 2;
        GameManager.Instancia.arregloPosicion[1] = CPU_Players[1].gameObject;
        Lugar2.sprite = CPU_Players[1].GetComponent<ContadorLaps>().ImagenJugador;

    }

    void ObtenSegundolugar2()
    {

        CPU_Players[2].PosicionEnLaCarrera = 2;
        GameManager.Instancia.arregloPosicion[1] = CPU_Players[2].gameObject;
        Lugar2.sprite = CPU_Players[2].GetComponent<ContadorLaps>().ImagenJugador;

    }

    void ObtenTercerlugar0()
    {
        CPU_Players[0].PosicionEnLaCarrera = 3;
        GameManager.Instancia.arregloPosicion[2] = CPU_Players[0].gameObject;
        Lugar3.sprite = CPU_Players[0].GetComponent<ContadorLaps>().ImagenJugador;
    }

    void ObtenTercerlugar1()
    {

        CPU_Players[1].PosicionEnLaCarrera = 3;
        GameManager.Instancia.arregloPosicion[2] = CPU_Players[1].gameObject;
        Lugar3.sprite = CPU_Players[1].GetComponent<ContadorLaps>().ImagenJugador;

    }

    void ObtenTercerlugar2()
    {

        CPU_Players[2].PosicionEnLaCarrera = 3;
        GameManager.Instancia.arregloPosicion[2] = CPU_Players[2].gameObject;
        Lugar3.sprite = CPU_Players[2].GetComponent<ContadorLaps>().ImagenJugador;

    }

}

   

