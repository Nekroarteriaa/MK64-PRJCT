﻿using UnityEngine;
using System.Collections;

public class Posicion_de_seguido : MonoBehaviour {

    /*
    GameObject PC;
    public GameObject VacioObjetivo_Uno;
    public GameObject VacioObjetivo_Dos;
    GameObject[] Hijos_Pos_Vacio;
    public GameObject[] posiciones;
    public int pos;
    int numran1;
    int numran2;
    */
    // Use this for initialization

    public GameObject[] posiciones;
    public GameObject VacioPadre_Objetivos;
    public GameObject ObjetivoASeguir;
    GameObject[] Hijos_Pos_Vacio;
    public int pos;
    int numran;


    public float velocidadVacio;
    float velocidadOriginal;

    void Start ()
    {
        /*
        Hijos_Pos_Vacio = new GameObject[transform.childCount];
        for (int i = 0; i < transform.childCount; i++)
        {
            //
           
            Hijos_Pos_Vacio[i] = transform.GetChild(i).gameObject;

        }
        numran1 = Random.Range(0, Hijos_Pos_Vacio.Length);
        numran2 = Random.Range(0, Hijos_Pos_Vacio.Length);
        */
        VacioPadre_Objetivos.transform.position = posiciones[0].transform.position;
        Hijos_Pos_Vacio = new GameObject[VacioPadre_Objetivos.transform.childCount];

        for (int i = 0; i < VacioPadre_Objetivos.transform.childCount; i++)
        {


            Hijos_Pos_Vacio[i] = VacioPadre_Objetivos.transform.GetChild(i).gameObject;

            

        }

       
        numran = Random.Range(0, Hijos_Pos_Vacio.Length);

        velocidadOriginal = velocidadVacio;
    }
	
	// Update is called once per frame
	void Update ()
    {
        float distancia = Vector3.Distance(VacioPadre_Objetivos.transform.position, transform.position);



        if(distancia <= 3)
        {
            pos++;
            numran = Random.Range(0, Hijos_Pos_Vacio.Length);
        }

       
        
        for(int i = 0; i < posiciones.Length; i++)
        {
            if (i == pos)
            {
                VacioPadre_Objetivos.transform.position = posiciones[i].transform.position;
                VacioPadre_Objetivos.transform.rotation = posiciones[i].transform.rotation;

                //ObjetivoASeguir.transform.position = Hijos_Pos_Vacio[numran].transform.position;

               
                //ObjetivoASeguir.transform.position = Hijos_Pos_Vacio[numran].transform.position;
            }

            else
            {
                posiciones[i].SetActive(false);
            }

            Vector3 mirarhacia = Hijos_Pos_Vacio[numran].transform.position - ObjetivoASeguir.transform.position;
            ObjetivoASeguir.transform.rotation = Quaternion.LookRotation(mirarhacia);
            ObjetivoASeguir.transform.Translate(Vector3.forward * velocidadVacio * Time.deltaTime);

            //////float DistanciaPuntoObjetivo = Vector3.Distance(Hijos_Pos_Vacio[numran].transform.position, ObjetivoASeguir.transform.position);

            //////if (DistanciaPuntoObjetivo < .5)
            //////{
            //////    ObjetivoASeguir.transform.Translate(Vector3.zero * velocidadVacio * Time.deltaTime);
            //////}

            //////if (DistanciaPuntoObjetivo > .5)
            //////{
            //////    ObjetivoASeguir.transform.Translate(Vector3.forward * velocidadVacio * Time.deltaTime);
            //////}


            ////if (ObjetivoASeguir.transform.position == Hijos_Pos_Vacio[numran].transform.position)
            ////{
            ////    ObjetivoASeguir.transform.Translate(Vector3.zero * velocidadVacio * Time.deltaTime);
            ////}

            ////else if (ObjetivoASeguir.transform.position != Hijos_Pos_Vacio[numran].transform.position)
            ////{
            ////    ObjetivoASeguir.transform.Translate(Vector3.forward * velocidadVacio * Time.deltaTime);
            ////}

        }
        
        //if (pos == 0)
        //{
        //    /*
        //    transform.position = posiciones[0].transform.position;
        //    transform.rotation = posiciones[0].transform.rotation;

        //    VacioObjetivo_Uno.transform.position = Hijos_Pos_Vacio[numran1].transform.position;
        //    VacioObjetivo_Dos.transform.position = Hijos_Pos_Vacio[numran2].transform.position;
        //    */
        //    VacioPadre_Objetivos.transform.position = posiciones[pos].transform.position;

        //}

        //if (pos == 1)
        //{
        //    /*
        //    transform.position = posiciones[1].transform.position;
        //    transform.rotation = posiciones[1].transform.rotation;
        //    */
        //    VacioPadre_Objetivos.transform.position = posiciones[pos].transform.position;

        //}

        //if (pos == 2)
        //{
        //    /*
        //    transform.position = posiciones[2].transform.position;
        //    transform.rotation = posiciones[2].transform.rotation;
        //    */
        //    VacioPadre_Objetivos.transform.position = posiciones[pos].transform.position;
        //}
        
    }


}
