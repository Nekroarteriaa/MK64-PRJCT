﻿using UnityEngine;
using System.Collections;

public class Comportamiento_Base : MonoBehaviour {

    // Use this for initialization
    NavMeshAgent navmeshagent;
    public Transform objetivo;
    public GameObject[] puntosSeguida;
    public int CambioPosicionObjetivo;
	void Start ()
    {

        navmeshagent = GetComponent<NavMeshAgent>();

        CambioPosicionObjetivo = 0;

        float VelocidadRandom = Random.Range(12.8f, 13.5f);

        navmeshagent.speed = VelocidadRandom;

        print(navmeshagent.speed + " " + transform.gameObject.name);
        

    }
	
	// Update is called once per frame
	void Update () {

        navmeshagent.SetDestination(objetivo.position);

        

        if (CambioPosicionObjetivo >= puntosSeguida.Length)
        {
            CambioPosicionObjetivo = 0;
        }

        objetivo.transform.position = puntosSeguida[CambioPosicionObjetivo].transform.position;

    }

    void OnTriggerEnter(Collider col)
    {
        if (col.gameObject.tag == "Puntos_Seguida")
        {

            CambioPosicionObjetivo += 1;
           // print(CambioPosicionObjetivo + " " + "Uno");
        }
    }

    void OnTriggerExit(Collider col)
    {

        //if (col.gameObject.tag == "Puntos_Seguida")
        //{

        //    CambioPosicionObjetivo += 1;
        //    print(CambioPosicionObjetivo + " " + "Uno");
        //}


        //if (col.gameObject.tag == "Salida")
        //{

        //    CambioPosicionObjetivo += 1;
        //}




    }
}
