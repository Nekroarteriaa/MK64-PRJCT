Thank you for purchasing and installing ProBuilder! Your support allows us to continue improving these tools, and adding new ones.

Helpful Links:

1) Video tutorial series at http://www.youtube.com/playlist?list=PLrJfHfcFkLM8PDioWg_5nmUqQycnVmi58

2) Having any issues? Post to the official forum at www.procore3d.com/forum

3) Documentation at www.procore3d.com/docs/probuilder

Keep in-touch, and help spread the word!

Twitter: @ProBuilder3D
Facebook: facebook.com/probuilder3d
Email: contact@procore3d.com

Best,
Gabriel W
Karl H